
// This logic has been consolidated into index.tsx to ensure consistent global window.app initialization.
